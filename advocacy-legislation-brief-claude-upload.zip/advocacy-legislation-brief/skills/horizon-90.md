# Horizon-90 — Research Workflow and Output

Sub-skill of `legislative-briefing-skill`. Load this file when the user
requests a forward-looking scan of what's coming over the next 90 days —
not what to act on right now, but what to prepare for.

The parent skill (`SKILL.md`) has completed Step 0 (state context loaded) and
provides the shared accuracy and style rules. Begin at Step 1.

**This is a planning document, not an action document.** The monthly digest
answers "what's moving this month, call now." The short brief answers "act
on this one bill now." This sub-skill answers "what's coming in the next 90
days so group leaders can recruit, schedule, and budget volunteer time
ahead of it." No call scripts, no phone numbers — point readers to the
digest or a short brief once an item actually enters its action window.

**Output format: docx.** Use `templates/brief-base.js`. Same minimal
formatting as the digest: bold for issue headlines and field labels,
plain paragraphs for body text. One two-column table near the top
(`Looking Ahead at a Glance`) — see Docx Layout Defaults in
`references/docx-conventions.md` for the two-column constraint that applies
to every table except the delegation reference table.

**Audience:** Group leaders and steering committee members planning the
organizing calendar, not reacting to today's news.

**Time window:** Rolling 90 days from the date the scan is run. State the
scan date and the resulting window explicitly in the document header.

**Length target:** 6–10 items, organized chronologically by month, not by
importance.

---

## Research Workflow

### Step 1 — Build the calendar backbone first

Before looking for legislative items, establish the structural calendar for
the 90-day window. **Start from `calendar-119.md`**, which holds the session
weeks, recess periods, and statutory deadlines for this Congress so they are
not re-researched on every scan. If it is unpopulated or its verification date
predates a leadership revision, fill it in from the published calendars it
cites rather than working around it.

Then confirm the rest:

- House and Senate floor calendars — confirm which weeks are session weeks
  and which are recess/district weeks
- Statutory deadlines falling inside the window: appropriations or
  continuing-resolution deadlines, program reauthorization expirations,
  debt limit dates if applicable
- federalregister.gov effective dates for major pending rules
- dailypress.senate.gov for any already-confirmed Senate floor schedule

Recess weeks matter as much as session weeks. No floor action happens
during them, and they are often the best window for district-based
visibility events. Cite a source for every date. Do not estimate a date
without a primary source backing it.

### Step 2 — Scan for legislative and agency items with timing inside the window

Sources:

- `./scripts/fetch-signals.sh` — the civic-signals collector feed (Federal
  Register, regulations.gov). Run it first: it surfaces candidates the manual
  sources below might miss, and its Certainty/Reliability columns feed
  directly into Step 3. Treat every row as a candidate, never a verified fact
  — Accuracy Rule 6 still applies before anything from it reaches an output.
- congress.gov — committee markup schedules, scheduled floor votes
- Committee websites — many publish markup calendars several weeks out
- `references/sources-national.md`'s "Leading Indicators" section — required,
  not optional, for agency action: reginfo.gov for rules under Office of
  Information and Regulatory Affairs (OIRA) review, federalregister.gov's
  public-inspection list for documents publishing the next day, regulations.gov
  for open comment deadlines, openomb.org for apportionment footnotes, gao.gov
  for Impoundment Control Act decisions
- News sources per `references/sources-national.md`, for "leadership
  intends to move this by [date]" signals
- indivisible.org national priorities — one input, not a required list

Cast a wide net: pull 12–15 candidates before narrowing.

### Step 3 — Classify every candidate by certainty

This is the structural, per-item application of SKILL.md's Shared Accuracy
Rule on future dates ("never state a future date as more certain than it
is"). Use exactly these three labels as a tag on every item. Never blend
them or soften the distinction:

- **Scheduled** — a confirmed date exists on a calendar or committee notice
- **Expected** — leadership or a committee has stated intent to act in this
  window, but no confirmed date exists yet
- **Watch** — could move into the window depending on developments (a court
  ruling, a negotiation outcome) but timing is not yet knowable

Do not assign a Scheduled date unless a primary source actually published
it. An Expected item with no date is more honest than an Expected item with
a guessed one.

**Agency items follow the same three labels.** A rule listed under OIRA
review with no confirmed publication date is Watch — OIRA review timing is
not predictable from the listing alone. A published comment deadline or a
stated rule effective date is Scheduled — the date is fixed by the Federal
Register notice itself, not by anyone's intent.

### Step 4 — Coverage check across issue areas

Before narrowing to 6–10 items, confirm the 12–15 candidates from Step 2
touch every issue area from `issues/_template.md`'s Issue area field:
elections, immigration, health, education, environment, budget, federal
workforce, civil liberties. An area with nothing worth watching this window
is a legitimate outcome — name it in the closing note (see Output Format)
rather than silently dropping it. An area with no candidate because no one
looked for one is not that outcome; check that area's sources in Step 2
again before concluding it is quiet.

### Step 5 — Select 6–10 items

Prioritize by:

1. **Virginia relevance** — a Virginia member has leverage, or the item has
   a state-specific impact
2. **Decision weight** — items that are hard to reverse once decided
   (confirmations, appropriations riders, reauthorizations) over items that
   are easily revisited later
3. **Spread across the window** — do not let every item cluster in the
   first two weeks. If the back half of the window is genuinely thin, say
   so in the closing note rather than padding with low-confidence Watch
   items to hit a count

Drop anything already covered in depth by a current full brief or short
brief. Link to that document instead of duplicating it.

### Step 6 — Confirm the Virginia angle for each selected item

Same accuracy rule as every other output type: one sourced sentence on why
it matters for Virginia specifically. Skip deep donor or impact research —
this is a planning document, not a persuasion document. If no
Virginia-specific angle exists, write that plainly rather than forcing one.

### Step 7 — Set or update each item's issue stage

For every selected item, open (or create) its `issues/<slug>.md` file and
set or update the Stage field per SKILL.md's "CTA Readiness" section. This
scan is often the first place a `watch` item's decision point firms up
enough to become `prepare`, or where a `prepare` item's remaining condition
gets met.

The output's **Prepare:** line (see Output Format) comes from that file's
**Blocker** field — it names what organizers can do while the unmet
condition holds, such as collecting constituent stories or lining up media
contacts, not a generic prep task invented for the write-up.

**If this scan's research moves an item all the way to `cta-ready`,** it no
longer belongs in this document. Horizon-90 is for items not yet
actionable; a `cta-ready` item is actionable now, has no Blocker left to
write a Prepare line from, and belongs in the next digest or CTA roundup
instead. Drop it from the selected item list, note in the closing note that
it moved to `cta-ready`, and pull a replacement from the Step 2 candidate
pool if this drops the count below 6.

---

## Output Format

Write `horizon-90-[scan-date].js` in the project root (e.g.
`horizon-90-2026-06-19.js`), then follow `references/docx-conventions.md`'s
"Briefing file lifecycle," substituting `horizon-90-[scan-date]` for
`<topic>-brief`: run `./scripts/check-acronyms.sh`, run `node` to generate
the docx, `cp` to Google Drive, then `mv` both files to `briefs/`.

### Document header

```
90-Day Outlook — Virginia Indivisible
Scan date: [Month D, Year]  |  Window: [Month D] – [Month D, Year]
```

### "Looking Ahead at a Glance" table

Two-column table, per the Docx Layout Defaults rule in
`references/docx-conventions.md` — never add a third column.

- **Column 1:** Window (e.g., "Week of June 23," "Expected July," "No
  window yet")
- **Column 2:** Item name plus certainty tag, e.g. "MEDICAID CUTS MARKUP
  (Scheduled)"

Sort rows chronologically. Group all Watch items with no confirmed window
into a single trailing row group at the bottom rather than interspersing
them by guessed timing.

### Per-item structure

Group items under actual calendar month headings (not "next 30 days," which
drifts meaning between scan runs).

```
[ISSUE NAME — bold, all caps]          [Scheduled | Expected | Watch]

Window: [specific date, date range, or "no confirmed window yet"]

[2-3 sentences: what's expected to happen and the mechanism — markup,
floor vote, rule effective date, anticipated ruling.]

Virginia angle: [one sentence, or "No Virginia-specific angle identified."]

Prepare: [one sentence of concrete organizational prep, drawn from the issue
file's Blocker field per Step 7 — recruiting, scheduling, drafting
materials, collecting constituent stories. Not a call script. Once an item
enters its actual action window, it belongs in the digest or a short brief.]
```

### Closing note — recess weeks and coverage

List the recess/district weeks that fall inside the window explicitly.
Group leaders use these for district-based visibility events when no floor
action will compete for member attention. If the back half of the window
is thin on confirmed items, say so here rather than padding the item list.

Name any issue area from Step 4's coverage check that had nothing worth
watching this window, so a quiet area reads as checked rather than missed.

Name any item dropped per Step 7 for reaching `cta-ready` during this scan,
so a reader who expected it here knows to look for it in the next digest or
CTA roundup instead.

---

## Style rules

See SKILL.md "Shared Style Rules" for em dash, concrete nouns, and
sentence-length rules that apply to all output types.

- **Navy only, never red.** Per the Docx Layout Defaults rule in
  `references/docx-conventions.md`, red is reserved for standalone
  urgent-threat sections. Every item in this document is future or
  uncertain by design, even Scheduled ones — that is a different urgency
  class than "happening now." Use navy throughout.
- **The certainty tag must match Step 3 exactly.** Never describe an
  Expected or Watch item's timing as if it were confirmed.
- **No member contact details, no call scripts.** This is a calendar, not
  an action sheet. If a reader needs to act now, point them to the
  digest or a short brief.

---

## Pre-Delivery Check

Run SKILL.md's Shared Pre-Delivery Check first. It covers acronyms, em dashes,
position phrasing, primary-source status, future-date tagging, the acronym
checker, and the humanizer pass. Then verify these horizon-specific items:

- [ ] Every item has a Scheduled / Expected / Watch tag matching Step 3
- [ ] No invented dates — every Scheduled date traces to a primary source
- [ ] Step 4's coverage check ran; any issue area with nothing worth
      watching is named in the closing note
- [ ] Every selected item's issue file has an updated Stage (Step 7), and
      each Prepare line is drawn from that file's Blocker field
- [ ] Recess/district weeks inside the window are listed
- [ ] 6–10 items, sorted chronologically by month
- [ ] Glance table is two-column
- [ ] No phone numbers or call scripts included
- [ ] Virginia angle present, or explicitly marked absent, for every item
- [ ] Docx generated and opens without validation errors
- [ ] Both .js and .docx moved to briefs/

---

## Common Pitfalls

- **Treating Expected as Scheduled.** Leadership "wanting" a vote by a
  certain date is not the same as a markup notice existing. Tag accurately.
- **Padding the back half of the window.** If confirmed items thin out
  past day 45, say so in the closing note instead of filling the gap with
  low-confidence Watch items just to hit 6–10.
- **Writing this like a digest.** No call-now asks. The point is
  organizational lead time, not a phone call this week.
- **Forgetting recess weeks.** A group leader who doesn't know Congress is
  out may schedule a Hill-focused action against a closed building, or miss
  the best window for a district-based event.
- **Forcing a Virginia angle that doesn't exist.** Write "No
  Virginia-specific angle identified" rather than stretching a national
  story into a state hook that doesn't hold up.
