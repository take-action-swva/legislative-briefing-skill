# Short Brief — Research Workflow and Output

Sub-skill of `legislative-briefing-skill`. Load this file when the user
requests a short brief, quick summary, or copy-paste-ready message for
distribution via Gmail, Signal, Discord, or Slack.

The parent skill (`SKILL.md`) has completed Step 0 (state context loaded) and
provides the shared accuracy rules. Begin at Step 1.

**Output format: markdown.** Do not produce a docx file. The output must be
readable as plain text in platforms that do not render markdown (Signal, plain
Gmail). Use bare URLs, not markdown link syntax — `[text](url)` does not
render in Signal or plain-text email.

**This brief links to the full brief rather than replacing it.** Generate or
locate the full briefing `.docx` on Google Drive before writing the short
brief, and include the link at the end. If no full brief exists yet, note that
one should be produced.

**Length target: 300–400 words.** Fits one Signal or Discord message without
excessive scrolling. Trim aggressively — every sentence must earn its place.

---

## Research Workflow

### Step 1 — Confirm the bill or EO identity

Same as the full brief: confirm exact bill number, Congress session, and
whether the legislation has been renamed or superseded. This step is the same
regardless of output length — a wrong bill number in a short brief sent to
hundreds of group leaders is worse than in a long document.

### Step 2 — Verify current status

Check congress.gov for current status and the next scheduled procedural moment.
Check dailypress.senate.gov if the bill has been on the Senate floor.
Do not rely on news summaries for status.

One question to answer before writing: **What is the single next decision
point, and when is it?** Everything in this brief flows from that.

### Step 3 — Identify the 2–3 most actionable members right now

Classify the full delegation using SKILL.md's Shared Member Taxonomy, then
publish only the two or three with the most leverage on this bill right now.
Follow the shared contact ranking: Gatekeepers first regardless of tier, then
Tier 2 Movable, then Tier 1 Aligned, then Tier 3 Locked.

In practice a short brief is mostly Gatekeepers and Tier 2 members, because
those are where a phone call changes an outcome this week. A Tier 3 Locked
member belongs here when they are genuinely the highest-leverage target — the
only delegation member on the committee of jurisdiction, say. Include them with
the documentation framing from the taxonomy, so a caller knows a logged refusal
is the point rather than a failure.

Do not list a member merely because they are senior or on a relevant committee
if someone else is more movable. Two or three is enough — more dilutes the ask.

Skip `brief-full.md`'s Step 4 (deep state-specific impact research) unless a
key statistic is already known or quickly found in a senator's press release.
Do not delay the brief to chase state data.

### Step 4 — Confirm the full brief link

Check `brief-index.md` first — it lists everything published to the Drive
folder, and is faster and more reliable than searching Drive. Confirm the URL
for the full briefing document before writing, and include it at the end of
the short brief. If the index has no row for this bill, no full brief exists
yet; say so rather than linking to something adjacent.

### Step 5 — Produce and archive the file

Write `<topic>-short-brief.md` in the project root. Run
`./scripts/check-acronyms.sh <topic>-short-brief.md` and fix every FAIL. Then
follow `references/docx-conventions.md`'s "Briefing file lifecycle" from the
copy step onward: `cp` the `.md` to Google Drive, then `mv` it to `briefs/`.
The message you paste into Signal or Gmail is this file's content, but the
file itself is archived
so the Drive folder holds every deliverable.

---

## Output Format

Produce clean markdown. Write so the output is readable even where markdown
does not render — avoid nested formatting, use plain dashes for bullets, and
use bare URLs not link syntax.

### Structure (in order)

**1. Hook — 1–2 sentences**
What is happening right now and why it matters. No background, no history.
Lead with the threat or opportunity, not the bill's name.

Example:
> The Senate could vote on H.R. 22 as early as next week. If it passes, an
> estimated 21 million eligible voters in Virginia lose access to same-day
> registration.

**2. Act now — 2–3 members maximum**
One entry per member, in the shared contact ranking order. Each entry on its
own line block:

```
**[Name] — [Role/why they matter right now]**
DC: [phone number]
Contact: [bare URL to contact form]
Ask: [one sentence on what to say — not a full script]
```

No call scripts. The ask line is one directive sentence, not a script.
Phone numbers and contact URLs must be present — do not omit them.
Pull contact info from `state-context-va.md` — do not search for it.

**3. Why it matters — 2 bullets, 3 maximum**
Bold key phrase, then one tight sentence. Two bullets is often better than three — don't pad.
Cut anything that does not directly reinforce the action ask. Specifically: do not include
framing that argues for the opposition's position, even if it appeared in source material.

**4. Next trigger — 1 line**
The single next decision point and its deadline.

Example:
> Next: Senate floor vote expected week of June 23. Call before then.

**5. Full briefing link**
One line. Bare URL.

Example:
> Full briefing (Virginia Indivisible): https://drive.google.com/...

---

## Style rules

- **No jargon without a gloss.** If you use "cloture" or "markup," add a
  parenthetical. Group leaders on Signal are not reading slowly.
- **Acronyms on first use.** Same rule as the full brief — expand on first
  mention even in a short document.
- **Plain URLs only.** Do not use `[text](url)` markdown link syntax.
  Signal and plain-text Gmail show this as literal bracket text, not a link.
- **No footnotes, no endnotes, no citation brackets.** Sources are in the
  full brief. The short brief does not carry inline citations.
- **Active voice, short sentences.** Aim for eighth-grade reading level.
  These messages are read fast, often on a phone, often mid-meeting.
- See SKILL.md "Shared Style Rules" for em dash, concrete nouns, and
  sentence-length rules that apply to all output types.

---

## Pre-Delivery Check

Run SKILL.md's Shared Pre-Delivery Check first. It covers acronyms, em dashes,
position phrasing, primary-source status, future-date tagging, the acronym
checker, and the humanizer pass — for this output type the humanizer applies
to the hook, the why-it-matters bullets, and the ask lines. Then verify these
short-brief-specific items:

- [ ] Bill number and Congress session correct
- [ ] Action members are the most movable right now — not just the most senior
- [ ] Each action entry has phone number and contact URL from state-context-va.md
- [ ] Next trigger date is specific — not "soon" or "in coming weeks"
- [ ] Full brief link present and resolves
- [ ] Total word count under 400
- [ ] Readable as plain text — no markdown link syntax, no nested formatting

---

## Common Pitfalls

- **Listing too many members.** Two or three is enough. More than three and
  group leaders call nobody.
- **Dropping a Locked member who is the real lever.** The two-or-three cap is
  a space constraint, not a rule that opponents go uncontacted. If the only
  delegation member on the committee of jurisdiction is Tier 3, they belong in
  the brief with the documentation framing.
- **Burying the ask.** The action section comes before the background bullets,
  not after. Leaders who stop reading after the hook still know who to call.
- **Using the full brief's "Why It Matters" section verbatim.** It was written
  for a different reading context. Rewrite for scan speed.
- **Forgetting the full brief link.** The short brief's job is to drive people
  to call and to read more. Without the link, half the job is missing.
- **Writing "position not publicly stated."** Use "position not found during
  research" — same rule as the full brief.
- **Including source framing that cuts against the action ask.** If a source
  uses urgency to argue for the opposition's position (e.g., "the program
  must be extended immediately for security reasons"), do not carry that
  framing into the brief even if the source is credible. Stick to what
  supports the recommended action.
